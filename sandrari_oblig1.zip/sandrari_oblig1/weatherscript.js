var locations = [
    { name: 'Oslo', url: 'https://api.open-meteo.com/v1/forecast?latitude=59.9139&longitude=10.7522&current_weather=true' },
    { name: 'Stockholm', url: 'https://api.open-meteo.com/v1/forecast?latitude=59.3293&longitude=18.0686&current_weather=true' },
    { name: 'Rome', url: 'https://api.open-meteo.com/v1/forecast?latitude=41.9028&longitude=12.4964&current_weather=true' },
    { name: 'New York', url: 'https://api.open-meteo.com/v1/forecast?latitude=40.7128&longitude=-74.0060&current_weather=true' },
    { name: 'Riga', url: 'https://api.open-meteo.com/v1/forecast?latitude=56.9496&longitude=24.1052&current_weather=true' }
];

var weatherContainer = document.getElementById('weather-container');

function fetchWeather() {
    weatherContainer.innerHTML = '';

    locations.forEach(function(location) {
        fetch(location.url)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                return response.json();
            })
            .then(function(data) {
                displayWeather(location.name, data.current_weather);
            })
            .catch(function(error) {
                weatherContainer.innerHTML += 'Error fetching weather data for ' + location.name;
                console.error('Error: ' + error);
            });
    });
}

function displayWeather(cityName, currentWeather) {
    var weatherElement = document.createElement('div');
    weatherElement.classList.add('weather-info');
    

    weatherElement.innerHTML = 
        '<h3>' + cityName + '</h3>' +
        '<p>Temperature: ' + currentWeather.temperature + ' °C</p>' + 
        '<p>Wind Speed: ' + currentWeather.windspeed + ' km/h</p>' + 
        '<p>Wind Direction: ' + currentWeather.winddirection + '°</p>'
    
    weatherContainer.appendChild(weatherElement);
}

fetchWeather();
setInterval(fetchWeather, 60000); 