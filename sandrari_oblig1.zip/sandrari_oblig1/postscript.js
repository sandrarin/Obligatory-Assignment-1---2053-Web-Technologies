let currentPage = 1;
const postsContainer = document.getElementById('posts-container');
const postsPerPage = 3;
const url = 'https://jsonplaceholder.typicode.com/posts';

const fetchPosts = function(page, limit) {
    fetch(url + '?_page=' + page + '&_limit=' + limit)
        .then(function(response) {
            if (!response.ok) {
                throw new Error(response.statusText);
            }
            return response.json();
        })
        .then(showPosts)
        .catch(function(error) {
            console.error(error);
        });
};

const showPosts = function(posts) {
    posts.forEach(function(post) {
        const postElement = document.createElement('div');
        postElement.className = 'post';
        postElement.innerHTML = '<h3>' + post.title + '</h3>' + post.body;
        postsContainer.appendChild(postElement);
    });
};

window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 5) {
        currentPage++;
        fetchPosts(currentPage, postsPerPage);
    }
});

fetchPosts(currentPage, postsPerPage);

